## 2014-10-24 Release 0.1.0
### Summary

This release adds the feature to support `install_options` like the original gem provider. (Requires puppet 3.6.0 or later to work)

### Features
- Add `install_options` provider feature
